<div class="four wide column" id="example1">
    <div class="ui secondary vertical pointing menu">
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/index.php" ? "active" : "");?>" href="index.php">Dashboard</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/children.php" ? "active" : "");?>" href="./children.php">Children</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/tlogs.php" ? "active" : "");?>" href="./tlogs.php">Triggers</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/sponsorer.php" ? "active" : "");?>" href="./sponsorer.php">Sponsorers</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/donators.php" ? "active" : "");?>" href="donators.php">Donators</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/gift-sent.php" ? "active" : "");?>" href="gift-sent.php">Gift Sent</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/programs.php" ? "active" : "");?>" href="./programs.php">Programs</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/feedback.php" ? "active" : "");?>" href="feedback.php">Feedback</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/admin/newsletter.php" ? "active" : "");?>" href="./newsletter.php">Newsletter</a>
    </div>
</div>