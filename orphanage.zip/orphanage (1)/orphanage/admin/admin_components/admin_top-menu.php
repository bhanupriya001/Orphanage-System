<div class="ui inverted menu">
    <div class="header item">
        OFD Administrator
    </div>
    <a class="item" href="../index.php">Home</a>
    <div class="right menu">
        <a class="item" href="../logout.php">Logout</a>
    </div>
</div>